# AI-BMS demo (statik sayfa)

Build adımı yok, framework yok: tek `index.html`. Vercel bunu doğrudan statik site olarak yayınlar.

## Dosyalar
- `index.html`: demo (HTML, CSS, JS tek dosyada)
- `vercel.json`: arama motoru engeli ve güvenlik başlıkları
- `robots.txt`, `favicon.svg`

## Yayınlama yolları

**A) Vercel paneli (en kolay)**
1. Klasörü bir GitHub deposuna yükle.
2. vercel.com → Add New → Project → depoyu seç.
3. Framework Preset: **Other**. Build Command ve Output Directory boş kalsın. Deploy.

**B) Vercel CLI**
```
npm i -g vercel
cd ai-bms-demo
vercel          # önizleme bağlantısı
vercel --prod   # canlı bağlantı
```

## Notlar
- Sayfa `noindex` işaretli, Google'da çıkmaz. Ama bağlantıyı bilen herkes açabilir. Yönetime özel kalsın istiyorsan Vercel'de Deployment Protection (parola / giriş) ayarını aç; bu özelliğin plana bağlı olduğunu kontrol et.
- Yazı tipi Google Fonts'tan yüklenir. İnternetsiz sunumda sistem fontuna düşer, sayfa yine çalışır.
- Demo simülasyondur: veriler örnek, 4–6. adımlar POC'de kanıtlanan zinciri taklit eder, 1–3. adımlar (PDF/DWG ayrıştırma, AI çıkarımı) henüz doğrulanmadı. Sayfadaki rozetler bunu zaten gösteriyor.
- Gerçek müşteri verisi, parola veya proje dosyası bu klasöre koyulmamalı.
